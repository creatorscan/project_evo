from flask import Flask
import requests
import json
import time
from deepspeech_parser import *
#import subprocess
''' The functions to be done by command synthesizer is the following things:
    1. Receive the recognized text and then parsing it 
	2. Determine if the text is a meaningful command by comparing it to the list of commands in the config.json file or some other array of commands that are to be performed.
	3. Determine the target application the command should be sent. 
	4. Create the command.json file with the attributes like what is the command ?, where it should be executed ?, what type of handler(is it REST, SOAP or ARINC 429) to use for the target device.
	5. Send the command.json through the REST api call.   
'''
# find the source for copying files
'''
def find_source(text,source):
	if (text.find(source)== -1):
		return 1	
	else:
		return -1	
	#return source
# find the destination to copy files to
def find_destination(text, destination):
	if (text.find(destination)== -1):
		return 1	
	else:
		return -1
	#return destination'''
# check if the recognized text has the keywords to create the command
def checktext(text): 
	print ("The Given text is :",text)
	with open ('config.json' ,'r') as f:
		config_dict = json.load(f)
	for config in config_dict:
		cmd = config['cmd']
		#print (cmd)
		calltype = config['type']
		target = config['target']
		#print ("The text found is:",text)
		if find_command(text,cmd)==1 and find_target(text,target)==1:
			print ("The Given text is a valid text , now creating command")
			print ("The cmd word present is ",cmd,"and the target word present is", target)
			send_command(cmd,target,calltype)
		#else:
		#	print ("command and target not found")
def find_target(text,target):
	if (text.find(target)!= -1):
		#print ("target found")
		return  1
	else:
		#print ("No target found")
		return -1
# Finds if valid command is present in the text
def find_command(text,cmd):
	if (text.find(cmd)!= -1):
		#print ("command found")
		return  1
	else:
		#print ("command Not found")
		return -1
def send_command(command,target,calltype):
	#print ("Inside the send_command function")
	data =[{
		'cmd' :command,
		'target': target,
		'type': calltype,
		'security':"allowed"
	}]
	s = json.dumps(data)
	res = requests.post('http://127.0.0.1:5000/', json=s).json()   
	print(res['code'])

def main():
	'''	
	print ('Inside main function')	
	text=subprocess.check_output(['./nnet3_online.sh'])
	#text = subprocess.call(['./nnet3_online.sh'])	
	print ("The got text is",text)
	print (type(text))
	'''
	while True:
		count=0
		text=live_recognizer()

		timestr = time.strftime("%Y%m%d-%H%M%S")
		textlog = 'textlog'+timestr
		print ("print in command synthesizer:",text)
		if text != None:
			with open(textlog, 'w') as f:    
       				f.write("\n"+text) 
			checktext(text)
		print ('/n No command found in recognized text, say again:\n')
		count+=1
		if count >3:
			textip=input("Enter the Text as i/p:")
			checktext(textip)
def test_audio():	
	while True:
	#Insted of live audio from mic use the test audio file 
		filename= input("enter the audiofile name:")
		text = test_wavs(filename)
		timestr = time.strftime("%Y%m%d-%H%M%S")
		textlog = 'textlog'+timestr
		print ("print in command synthesizer:",text)
		if text != None:
			with open(textlog, 'w') as f:    
       				f.write("\n"+text) 
			checktext(text)
print("1.Live audio mode\n 2.Testaudio mode")
choice=input("enter the mode to run code(1 or 2):")
if choice == '1':	
	main()
	
if choice == '2':
	test_audio()
